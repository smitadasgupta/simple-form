import React from 'react';
import ReactDOM from 'react-dom';

class IndecisionApp extends React.Component {
    render() {
        const title ="Indecision";
        const subtitle = "Put your life in the hand of computer";
        const options = ['One','Two','Three'];

        return (
            <div>
                <Header title={title} subtitle={subtitle}/>
                <Action/>
                <Options options={options}/>
                <AddOption/>
                <VisibilityCheck/>
            </div>
        );
    }
}

class Header  extends React.Component{ 
    render() {
       
        return (
        <div>
            <h1>{this.props.title}</h1>
            <h2>{this.props.subtitle}</h2>
        </div>
        );
    }
} 

class Action extends React.Component {
    render() {
        return (
        <div>
            <button>What should I do today?</button>
        </div>
        );
    }
}

class Options extends React.Component {
    constructor(props){
        super(props);
        this.handeleRemoveAll = this.handeleRemoveAll.bind(this);
    } 
    handeleRemoveAll() {
        console.log(this.props.options);
    }
    render() {
        return (
        <div>
            <button onClick={this.handeleRemoveAll}>Remove all</button>
            {
                this.props.options.map((option) => <Option key={option} optiontext={option}/>)
            }
            <Option/> 
        </div>
        );
    }
}

class Option extends React.Component {
    render() {
        return (
        <div>
            <p>{this.props.optiontext}</p>
        </div>
        );
    }
}

class AddOption extends React.Component {
    handleAddOption(e) {
        e.preventDefault();

        const option = e.target.elements.option.value.trim();

        if(option) {
            alert(option);
        }
    }
    render() {
        return (
        <div>
            <form onSubmit={this.handleAddOption}>
                <input type="text" name="option"/>
                <button>Add Option</button>
            </form>
        </div>
        );
    }
}


class VisibilityCheck extends React.Component {
    constructor(props) {
        super(props);

        this.isVisible = this.isVisible.bind(this);

        this.state = {
            visible: false
        }
    }
    isVisible() {
        this.setState((prevState) => {
            return {
                visible : !prevState.visible
            }
        });
    }
    render() {
        return (
            <div>
                <button onClick={this.isVisible}>{this.state.visible ? 'Hide Details' : 'Show details'}</button>

                {this.state.visible && (
                    <div>
                        <p>This is what you can see!</p>
                    </div>
                )
                }
            </div>
        );
    }
}


ReactDOM.render(<IndecisionApp/>, document.getElementById('app'));
